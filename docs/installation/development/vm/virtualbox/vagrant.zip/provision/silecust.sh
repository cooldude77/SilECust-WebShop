# -- clone
cd /var/www/html/silecust
git clone https://github.com/cooldude77/SilECust-WebShop.git /var/www/html/silecust/.
echo -e "DATABASE_URL=\"mysql://dbAdmin:dbPassword@127.0.0.1:3306/app_dev?serverVersion=10.11.2-MariaDB&charset=utf8mb4\"" > .env.local
composer install -vvv

# -- database 
php bin/console doctrine:database:create
php bin/console doctrine:migrations:migrate --no-interaction


echo 'Congratulations: Your installation is successful\n. You should be able to see site at http://192.168.200.10/silecust/public/index.php'